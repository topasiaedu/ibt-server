// src/models/ContactListMember.ts
export interface ContactListMember {
  contact_list_id: number;
  contact_id: number;
}
